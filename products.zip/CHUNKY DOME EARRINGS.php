<?php
session_start();
$insert = false;

// Set connection variables
$server = "localhost";
$username = "root";
$password = "";
$dbname = "projtest";

// Create a database connection
$con = mysqli_connect($server, $username, $password, $dbname);

// Check for connection success
if (!$con) {
    die("Connection to this database failed: " . mysqli_connect_error());
}

// Get the user_id from session
$user_id = $_SESSION['user_id'];

// Query to get the cart_id for the current user
$sql2 = "SELECT cart_id FROM projtest.cart WHERE user_id = $user_id";
$result2 = $con->query($sql2);

if ($result2 && $result2->num_rows > 0) {
    // Fetch the cart_id from the result
    $row = $result2->fetch_assoc();
    $cart_id = $row['cart_id'];

    // Check if 'item_name' is set to handle the "Add" button submission
    if (isset($_POST['item_name'])) {
        // Sanitize input values
        $item_name = mysqli_real_escape_string($con, $_POST['item_name']);
        $price = mysqli_real_escape_string($con, $_POST['price']);
        $quantity = mysqli_real_escape_string($con, $_POST['quantity']);
        $product_id = mysqli_real_escape_string($con, $_POST['product_id']); // Product ID from the form

        // SQL query to insert the item into the database
        $sql = "INSERT INTO projtest.cart_item (product_id, cart_id, quantity) VALUES ('$product_id', '$cart_id', '$quantity')";

        // Execute the query
        if ($con->query($sql) === true) {
            echo "Item added successfully!";
        } else {
            echo "ERROR: $sql <br> $con->error";
        }
    }
} else {
    echo "No cart found for the current user.";
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['rating']) && isset($_POST['msg']) && isset($_POST['product_id'])) {
        // Retrieve form inputs
        $rating = mysqli_real_escape_string($con, $_POST['rating']);
        $msg = mysqli_real_escape_string($con, $_POST['msg']);
        $product_id = mysqli_real_escape_string($con, $_POST['product_id']); // Add product_id to the review form
        $currentDate = date('Y-m-d'); // Current date


        // Check if user_id exists in the session
        if (!isset($_SESSION['user_id'])) {
            echo "User is not logged in.";
            exit;
        }
        
        // SQL query to insert review
        $sql = "INSERT INTO projtest.reviews (product_id, user_id, review_date, rating, comment) 
        VALUES ('$product_id', '$user_id', '$currentDate', '$rating', '$msg')";

        // Execute the query
        if ($con->query($sql) === true) {
            echo "Review submitted successfully!";
        } else {
            echo "ERROR: $sql <br> $con->error";
        }
    } else {
        echo "Please fill out all fields!";
    }
}

// Fetch product reviews
$sql3 = "
SELECT 
u.f_name, 
p.product_name, 
r.rating, 
r.comment 
FROM 
projtest.reviews r 
JOIN 
projtest.product p 
ON 
r.product_id = p.product_id 
JOIN 
projtest.user u 
ON 
r.user_id = u.user_id 
WHERE 
r.product_id = 10";

$result3 = $con->query($sql3);

// Query to get the total number of reviews for the product
$sql4 = "SELECT COUNT(*) as total_items FROM projtest.reviews WHERE product_id =10";
$result4 = $con->query($sql4);

$product_name1 = array();
$rating1 = array();
$comment1 = array();
$f_name1 = array();

// Fetch the reviews
if ($result3 && $result3->num_rows > 0) {
    while ($row = $result3->fetch_assoc()) {
        $product_name1[] = $row['product_name'];
        $rating1[] = $row['rating'];
        $comment1[] = $row['comment'];
        $f_name1[] = $row['f_name'];
    }
} else {
    echo "No reviews found for the product.";
}

// Fetch total items
$total_items = 0;
if ($result4 && $result4->num_rows > 0) {
    $row4 = $result4->fetch_assoc();
    $total_items = $row4['total_items'];
}

$div_contents = [];
if ($total_items > 0) {
    for ($i = 0; $i < $total_items; $i++) {
        $div_contents[] = "
        <div class='review'>
        <div class='review-header'>
        <strong>" . htmlspecialchars($f_name1[$i]) . "</strong>
        <br><br>
        <strong>" . htmlspecialchars($product_name1[$i]) . "</strong>
        <span class='rating'>Rating: " . htmlspecialchars($rating1[$i]) . " / 5</span>
        </div>
        <div class='review-body'>
        <strong>comment: </strong>
        <p>" . htmlspecialchars($comment1[$i]) . "</p>
        </div>
        </div>
        ";
    }
}
// Close the database connection
$con->close();
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Interface</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            /*display: flex;*/
            margin: 20px;
        }
        .container {
            display: flex;
            max-width: 1200px;
            margin: auto;
            width: 100%;
        }
        .product-image {
            flex: 1;
            padding: 20px;
        }
        .product-image img {
            width: 100%;
            border-radius: 10px;
        }
        .product-details {
            flex: 1;
            padding: 20px;
        }
        .product-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .price {
            color: #000;
            font-size: 20px;
            margin-bottom: 20px;
        }
        .color-selection, .size-selection {
            margin-bottom: 20px;
        }
        .size-options button {
            padding: 10px;
            margin: 5px;
            border: 1px solid #000;
            background-color: #fff;
            cursor: pointer;
        }
        .size-options button:hover {
            background-color: #f0f0f0;
        }
        .add-to-bag {
            background-color: #000;
            color: #fff;
            padding: 15px;
            text-align: center;
            cursor: pointer;
            border: none;
            font-size: 16px;
        }
        .add-to-bag:hover {
            background-color: #333;
        }
        .size-guide {
            text-decoration: underline;
            cursor: pointer;
            font-size: 14px;
        }
        .back-to-shop>a{
            text-decoration: none;
            /*margin-top: 4.5rem;*/
        }
        .back-to-shop > a:hover{
            font-size: 20px;
            transition: all 0.5s ease ; 
        }
        .back-to-shop > a{
            transition: all 0.5s ease;
        }
          .btn-primary {
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            background-color: white !important;
            color: black;
            transition: all 0.5s ease;
        }
         .reviews-section {
            margin-top: 20px;
            padding: 20px;
            border: 1px solid #d4d4d4;
            border-radius: 8px;
            background-color: #f9f9f9;
        }

        .reviews-section h3 {
            font-size: 24px;
            margin-bottom: 15px;
            color: #333;
            text-align: center;
            border-bottom: 2px solid #ddd;
            padding-bottom: 10px;
        }

        .review {
            border-bottom: 1px solid #e0e0e0;
            padding: 15px 0;
            margin-bottom: 15px;
        }

        .review:last-child {
            border-bottom: none;
            margin-bottom: 0;
        }

        .review-header {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .review-header .rating {
            float: right;
            font-size: 16px;
            color: #888;
        }

        .review-body {
            font-size: 16px;
            line-height: 1.5;
            color: #555;

        }

        .review-body>p{
            margin-top: 0px;
            padding-left: 10px;
        }
        
    </style>
</head>
<body>
    <div class="container">
        <div class="product-image">
            <img src="women/CHUNKY DOME EARRINGS.avif" alt="Product Image">
        </div>
        <div class="product-details">
            <div class="product-title">CHUNKY DOME EARRINGS</div>
            <div class="price">$8.99</div>
            <div class="color-selection">
                <div>COLOR: GOLD-COLORED</div>
                <br>
                <img src="women/CHUNKY DOME EARRINGS1.avif" alt="Color Sample" style="width: 150px; height: 150px; border: 1px solid black">
            </div>
            <form action="CHUNKY DOME EARRINGS.php" method="post">
                <input type="hidden" name="item_name" value="CHUNKY DOME EARRINGS"> 
                <input type="hidden" name="price" value="8.99"> 
                <input type="hidden" name="product_id" value="10"> <!-- Example product ID -->
                <input type="text" name="quantity" placeholder="ENTER QUANTITY">
                <button class="add-to-bag">ADD TO BAG</button>
            </form>

            <!-- <div class="back-to-shop"><a href="index3.php">&leftarrow;</a><span class="text-muted">Back to shop</span></div> -->

            <h4 style="margin-left: 0px; margin-bottom: 0px; border-bottom: 2px solid #cf0505; width: 21%; padding: 0px 0px 10px 0px; font-size: 15px; font-weight: 700;">YOUR REVIEW</h4><h4 class="line4"></h4>
            <form method="post" action="CHUNKY DOME EARRINGS.php">
                <div class="laname">
                    <label for="rating">Ratings:</label>
                    <input type="hidden" name="product_id" value="10">
                    <select id="rating" name="rating" required style="height: 35px; border: 1px solid #d4d4d4; padding: 5px 10px; width: 100%;">
                        <option value="" disabled selected>Select a rating</option>
                        <option value="1">1 - Poor</option>
                        <option value="2">2 - Fair</option>
                        <option value="3">3 - Good</option>
                        <option value="4">4 - Very Good</option>
                        <option value="5">5 - Excellent</option>
                    </select>
                </div>

                <br>
                <div>
                    <textarea id="msg" name="msg" placeholder="Enter Your Comment" style="width: 100%; padding: 5px 0px 0px 10px; height: 150px; border: 1px solid #d4d4d4"></textarea>
                </div>
                <br>
                <button type="submit" class="btn btn-primary" style="background-color: #1ba0da; border-radius: 0px; border: 2px solid; line-height: 28px; font-size: 16px; padding: 5px 20px; font-weight: 600; font-family: inherit; border-top: 2px solid #545454; border-left: 2px solid #545454; border-bottom: 2px solid black; border-right: 2px solid black; cursor: pointer; ">Submit
                </button>
            </form>
            <br>
            <div class="back-to-shop"><a href="index3.php">&leftarrow;</a><span class="text-muted">Back to shop</span></div>

        </div>
    </div>

    <div style="width: 70%; margin-left: 172px;">
        <br><br><br><br>
        <h4 style="margin-left: 0px; margin-bottom: 0px; border-bottom: 2px solid #cf0505; width: 10%; padding: 0px 0px 10px 0px; font-size: 15px; font-weight: 700;">ALL REVIEWS</h4><h4 class="line4"></h4>
        <div class="reviews-section" style="width: 100%">
            <?php
            // Output the dynamically generated HTML content
            foreach ($div_contents as $content) {
                echo $content;
            }
            ?>
        </div>
    </div>
</body>
</html>
