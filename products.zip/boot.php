<?php
$insert = false;
// if(isset($_POST['name'])){ // Uncomment this if you want to check for POST submission
    // Set connection variables
$server = "localhost";
$username = "root";
$password = "";

    // Create a database connection
$con = mysqli_connect($server, $username, $password);

    // Check for connection success
if(!$con){
    die("connection to this database failed due to " . mysqli_connect_error());
}
echo "Success connecting to the db<br>";

    // Collect post variables
// if ($_SERVER['REQUEST_METHOD'] == 'POST') {
//     if (isset($_POST['name'])) {
//          $name = mysqli_real_escape_string($con, $_POST['name']);
//          $email = mysqli_real_escape_string($con, $_POST['email']);
//          $msg = mysqli_real_escape_string($con, $_POST['msg']);
//             // Corrected SQL syntax - remove quotes around table/column names
//          $sql = "INSERT INTO projtest.form (name, email, other) VALUES ('$name','$email','$msg');";
//             // $ser++;
//             // echo $sql . "<br>";

//             // Execute the query
//          if($con->query($sql) === true){
//                 // Flag for successful insertion
//             $insert = true;
//         } else {
//             echo "ERROR: $sql <br> $con->error";
//         }
//     }

    // Check if 'item_name' is set to handle the "Add" button submission
    if (isset($_POST['item_name'])) {
        $item_name = mysqli_real_escape_string($con, $_POST['item_name']);
        $price = mysqli_real_escape_string($con, $_POST['price']);
            // SQL query to insert the item into the database
        $sql = "INSERT INTO projtest.cart (name, price) VALUES ('$item_name','$price');";

            // Execute the query
        if ($con->query($sql) === true) {
            echo "Item added successfully!";
        } else {
            echo "ERROR: $sql <br> $con->error";
        }
    }




    // Close the database connection
$con->close();
// }
?>








<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Interface</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            margin: 20px;
        }
        .container {
            display: flex;
            max-width: 1200px;
            margin: auto;
            width: 100%;
        }
        .product-image {
            flex: 1;
            padding: 20px;
        }
        .product-image img {
            width: 100%;
            border-radius: 10px;
        }
        .product-details {
            flex: 1;
            padding: 20px;
        }
        .product-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .price {
            color: #000;
            font-size: 20px;
            margin-bottom: 20px;
        }
        .color-selection, .size-selection {
            margin-bottom: 20px;
        }
        .size-options button {
            padding: 10px;
            margin: 5px;
            border: 1px solid #000;
            background-color: #fff;
            cursor: pointer;
        }
        .size-options button:hover {
            background-color: #f0f0f0;
        }
        .add-to-bag {
            background-color: #000;
            color: #fff;
            padding: 15px;
            text-align: center;
            cursor: pointer;
            border: none;
            font-size: 16px;
        }
        .add-to-bag:hover {
            background-color: #333;
        }
        .size-guide {
            text-decoration: underline;
            cursor: pointer;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="product-image">
            <img src="men/boot.avif" alt="Product Image">
        </div>
        <div class="product-details">
            <div class="product-title">RHINESTONE EMBELLISHED BOOTS</div>
            <div class="price">$89.99</div>
            <div class="color-selection">
               <div>COLOR: BLACK</div>
                <br>
                <img src="men/boot1.avif" alt="Color Sample" style="width: 150px; height: 150px; border: 1px solid black">
            </div>
            <div class="size-selection">
                <div>SELECT SIZE</div>
                <div class="size-options">
                    <button>XS</button>
                    <button>S</button>
                    <button>M</button>
                    <button>L</button>
                    <button>XL</button>
                    <button>XXL</button>
                    <button>3XL</button>
                </div>
            </div>
            <form action="index3.php" method="post">
                <input type="hidden" name="item_name" value="boots"> 
                <input type="hidden" name="price" value="89.99"> 
                <button class="add-to-bag">ADD TO BAG</button>
            </form>      
        </div>
    </div>
</body>
</html>
